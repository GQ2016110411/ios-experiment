//
//  MyView.swift
//  第五次作业代码
//
//  Created by student on 2018/10/24.
//  Copyright © 2018年 XJW. All rights reserved.
//

import UIKit

class MyView:UIView{
}
